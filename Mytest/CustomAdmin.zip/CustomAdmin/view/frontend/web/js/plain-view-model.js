define(['ko'], function(ko) {
    return function(config) {
        this.message = 'This is test KN Js';
    }
});