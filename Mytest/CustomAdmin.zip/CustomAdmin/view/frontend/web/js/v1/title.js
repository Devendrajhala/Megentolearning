define(function() {
    'use strict';

    return function (config, element) {
        element.innertext="Version 1";
    }
    
});