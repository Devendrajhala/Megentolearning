define(function () {
    'use strict';
    console.log('-----Model loaded before compare products ----');
});