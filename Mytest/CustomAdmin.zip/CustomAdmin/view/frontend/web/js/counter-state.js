define(['ko'], function (ko) {
    'use strict';

    return ko.track({
        counter: 0,
        increment: 1
    });
});
