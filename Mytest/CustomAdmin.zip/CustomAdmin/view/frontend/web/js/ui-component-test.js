define(['uiElement'], function (UiElement) {
        'use strict';

        return UiElement.extend({
            defaults:{
                label: "First Ui Component",
                values: [10, 20, 30, 1024]
            }

        });
});